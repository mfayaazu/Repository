package com.fayaaz.ali.services;

import com.fayaaz.ali.models.User;

import java.util.List;

public interface UserService {

    List<User> getAllUsers();
}
