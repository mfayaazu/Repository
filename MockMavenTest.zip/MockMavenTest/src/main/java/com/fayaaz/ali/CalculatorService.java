package com.fayaaz.ali;

public interface CalculatorService {

    int add (int first,int second);
}
